package control;

import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Medicamento;

public class MedicamentoControl {
    private Vector<Medicamento>medicamento = new Vector ();
    private Vector<Medicamento>medicamentopc = new Vector ();
    private Vector<Medicamento>medicamentolj = new Vector ();
    private List<String> Datos;

   
    public void agregarMedicamentos(Vector<Medicamento>v){
        ProcesadorArchivotxt pa= new ProcesadorArchivotxt();
        try{
            pa.LeerDatos();
            Datos=(pa.Contenido());
            cargarBaseDatos(v);
        }catch(Exception ex) {
           Logger.getLogger(ProcesadorArchivotxt.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void cargarBaseDatos(Vector<Medicamento>v){
        
        String[] dato;
        for (int i=0; i < this.Datos.size(); i++ ){
            if (this.Datos.get(i) != null){
                String renglon = this.Datos.get(i);
                dato = renglon.split(",");
                v.add(new Medicamento(dato[0],dato[1],dato[2],dato[3],dato[4],dato[5]));
                }
            }
        }
    
    public  Medicamento consultarMedicamentos(String c,Vector<Medicamento>v){
        Medicamento me=null;
        for (int i=0; i <v.size(); i ++){
            Medicamento m=(Medicamento) v.get(i);
            if (m.getCodigo().equals(c)){
                me=m;break;
            }
        }
        return me;
    }
    
    public void eliminarMedicamentos (Medicamento m,Vector<Medicamento>v){  
        v.remove(m);
    }
   
    public Vector getMedicamentos() {
        return medicamento;
    }

    public void setMedicamentos(Vector medicamentos) {
        this.medicamento = medicamentos;
    }

    public Vector<Medicamento> getMedicamentosPC() {
        return medicamentopc;
    }

    public void setMedicamentosPC(Vector<Medicamento> medicamentosPC) {
        this.medicamentopc = medicamentosPC;
    }

    public Vector<Medicamento> getMedicamentosLJ() {
        return medicamentolj;
    }

    public void setMedicamentosLJ(Vector<Medicamento> medicamentosLJ) {
        this.medicamentolj = medicamentosLJ;
    }

    
    }
  
    
    

            

            

