package modelo;

public class Medicamento {
    
    private String codigo;
    private String nombre;
    private String forma;
    private String fechaCaducidad;
    private String via_consumo;
    private String dosis;

    public Medicamento() {  
    }
    
    public String getMedicamentos(){
        String total=this.codigo+","+ this.nombre + ","+this.forma+","+this.fechaCaducidad+","+this.via_consumo+","+this.dosis;
        return total; 
    }
    
    public Medicamento(String codigo, String nombre, String forma, String fechaC, String viaconsumo, String dosis) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.forma = forma;
        this.fechaCaducidad = fechaC;
        this.via_consumo = viaconsumo;
        this.dosis = dosis;
    } 

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getForma() {
        return forma;
    }

    public void setForma(String forma) {
        this.forma = forma;
    }

    public String getFechaC() {
        return fechaCaducidad;
    }

    public void setFechaC(String fechaC) {
        this.fechaCaducidad = fechaC;
    }

    public String getViaconsumo() {
        return via_consumo;
    }

    public void setViaconsumo(String viaconsumo) {
        this.via_consumo = viaconsumo;
    }

    public String getDosis() {
        return dosis;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }
     
}
