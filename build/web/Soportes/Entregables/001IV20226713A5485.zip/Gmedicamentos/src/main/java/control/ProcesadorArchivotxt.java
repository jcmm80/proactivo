package control;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import modelo.Medicamento;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
public class ProcesadorArchivotxt {
    
  
    private List<String> datos = new ArrayList<String>();   
    public void LeerDatos() throws IOException, Exception {
        String contenidoArchivo;
        int pos = 0;
        try {
            FileReader fr = new FileReader("datofar.txt");
            BufferedReader dr = new BufferedReader(fr);
            while ((contenidoArchivo = dr.readLine()) != null) {
                this.datos.add(contenidoArchivo);
                pos++;
            }
        } catch (FileNotFoundException ex) {
            throw new Exception(ex.getMessage());
        }
    }
    public void GuardarMedicamento(Vector<Medicamento>listaMedicamentos)throws IOException, Exception {
        try {
            FileWriter fw =new FileWriter("datofar.txt");
            BufferedWriter bw = new BufferedWriter(fw);         
            for (int x = 0; x < listaMedicamentos.size(); x++) {
                 Medicamento lm =listaMedicamentos.get(x);
                 bw.write(lm.getMedicamentos()+System.lineSeparator());            
            }
            bw.close();
        } catch (FileNotFoundException ex) {
            throw new Exception(ex.getMessage());
        }     
    }
    public List<String> Contenido() {
        return this.datos;
    }   
}
