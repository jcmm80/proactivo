package control;

import java.util.ArrayList;
import java.util.List;
import modelo.Medicina;

public class ControlMedicina {
    private List<Medicina> medicinast=new ArrayList();
    private List<Medicina> medicinasp=new ArrayList();
    private List<Medicina> medicinasj=new ArrayList();
    

    public ControlMedicina() {
        generarMedicinast();
    }
    
    public void generarMedicinast(){
        medicinast.add(new Medicina("2202", "Plitican", "Tableta", "09/22/2022", "Oral","2/4 tabletas al día"));
        medicinast.add(new Medicina("3753", "Nifedipino", "Capsula", "06/30/2026", "Oral","3/4 al día (1/2 horas antes de comer)"));
        medicinast.add(new Medicina("6328", "Ambroxol", "Jarabe", "10/11/2022", "Oral","2/3 al día"));
        medicinast.add(new Medicina("10815", "Fluoxetina", "Capsula", "02/22/2023", "Oral","10/30 mg al día y 20/60 mg al día luego de 2 semanas"));
        medicinast.add(new Medicina("10816", "Ibuprofeno", "Pastilla", "02/22/2023", "Oral","3/4 cada 6/8 horas"));
        medicinast.add(new Medicina("11492", "Amoxicilina", "Papeleta", "08/31/2022", "Oral","2 al día cada 12 horas o 3 al día cada 8 horas"));
        medicinast.add(new Medicina("11697", "Acido Fusidico", "Crema", "09/11/2022", "Huntar","250mg 2/4 veces al día"));
        medicinast.add(new Medicina("11699", "Ketoprofeno", "Gel", "08/12/2027", "Huntar","3/4 al día o cada 6/8 horas"));
        medicinast.add(new Medicina("11878", "Tiopental", "Liquido", "05/05/2026", "Endovenosa","100/150mg 10/15 segundos repetidos luego de 30 segundos"));
    }
    
    public void agregar(Medicina A){
        medicinast.add(A);
    }
    
    public void quitar(Medicina A){
        medicinast.remove(A);
    }
    
    public Medicina consultar(String cod){
        Medicina pre=null;
        for(Medicina A:medicinast){
            if(A.getCodigo().equals(cod)){
                pre=A;break;
            }
        }        
        return pre;
    }

    public List<Medicina> getMedicinast() {
        return medicinast;
    }

    public void setMedicinast(List<Medicina> medicinast) {
        this.medicinast = medicinast;
    }

    public List<Medicina> getMedicinasp() {
        return medicinasp;
    }

    public void setMedicinasp(List<Medicina> medicinasp) {
        this.medicinasp = medicinasp;
    }

    public List<Medicina> getMedicinasj() {
        return medicinasj;
    }

    public void setMedicinasj(List<Medicina> medicinasj) {
        this.medicinasj = medicinasj;
    }
}    