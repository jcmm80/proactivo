package medicamentos;

public class Medicamento {
    public static void main(String[] args) {
    }
}