package modelo;

public class Medicina {
    private String Codigo;
    private String Nombre;
    private String Forma;
    private String Caducidad;
    private String ViaConsumo;
    private String Dosis;
    
    public Medicina(){
    }
    public Medicina(String Codigo,String Nombre,String Forma,
            String Caducidad, String ViaConsumo, String Dosis){
    this.Codigo = Codigo;
    this.Nombre = Nombre;
    this.Forma = Forma;
    this.Caducidad = Caducidad;
    this.ViaConsumo = ViaConsumo;
    this.Dosis = Dosis;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getForma() {
        return Forma;
    }

    public void setForma(String Forma) {
        this.Forma = Forma;
    }

    public String getCaducidad() {
        return Caducidad;
    }

    public void setCaducidad(String Caducidad) {
        this.Caducidad = Caducidad;
    }

    public String getViaConsumo() {
        return ViaConsumo;
    }

    public void setViaConsumo(String ViaConsumo) {
        this.ViaConsumo = ViaConsumo;
    }

    public String getDosis() {
        return Dosis;
    }

    public void setDosis(String Dosis) {
        this.Dosis = Dosis;
    }
}